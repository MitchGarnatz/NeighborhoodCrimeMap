function init() {
    console.log('Hello world!');
}